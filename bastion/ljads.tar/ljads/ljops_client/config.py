#!/usr/bin/python
# -*- coding: utf-8 -*-
# 加密密钥
SECRET_KEY="mmmmasdfklasjdfkdsjkfjjiozji"

SERVER='172.17.0.2'
PORT=9911

USER="admin"
PASSWD = "mmmmabcdefghijklmnopqrstuvwxyz"
