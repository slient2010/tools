#!/usr/bin/python
# -*- coding:utf-8 -*-
# 
# 说明： 客户端，集成到web或者独立使用。
# 
# 

import sys
import rpyc
from libs.libraries import *
from config import *
# import logging
# 常量定义，集成到web时候，可以不要config.py
# SECRET_KEY="asdfklasjdfkdsjkfjjiozji"
# SERVER='127.0.0.1'
# PORT=9911
# USER="admin"
# PASSWD="abcdefghijklmnopqrstuvwxyz"


class MangeGameServer(object):
	def __init__(self, *args, **kwargs):
		'''
		初始化
		'''
		self.server = SERVER
		self.port = PORT
		self.user = USER
		self.passwd = PASSWD
		self.mid = '1007'

	# def parser_request(self, serverlists, taskid, action):
	# def parser_request(self, *args, **kwargs):		
	def parser_request(self, **kwargs):				
		'''
		解析用户请求
		格式要求字符串：模块id@@serverip@@domain@@platname@@game_name@@action,以@@为分割，在web页面构造请求
		put_string="1007" + "@@" + "172.72.0.3" + "@@" + "www.baiduwebgame.com" + "@@" + "baidu"+"@@" + "rxtl_s1" + "@@" + "restart"
		'''

		get_request_string = []
		self.action = kwargs['action']
		if 'serverlists' in kwargs:
			self.serverlists = kwargs['serverlists']
			for serverlist in self.serverlists:
				info = serverlist.split('-')
				ip = info[0]
				domain = info[1]
				platid = info[2]
				game = info[3]
				actionstring = str(self.mid + "@@" + ip + "@@" + domain + "@@" + str(platid) + "@@" + game + "@@" + '%s' % self.action)
				get_request_string.append(actionstring)
		elif 'taskid' in kwargs:
			self.taskid = kwargs['taskid']
			actionstring = str(self.mid + "@@" + '%s' % self.taskid + "@@" + '%s' % self.action)
			get_request_string.append(actionstring)
		else:
			return r"game data format error"
		put_string = ""
		for i in range(len(get_request_string)):
			put_string = get_request_string[i] + "##" + put_string 
		# put_string="1007@@172.72.0.3@@www.baiduwebgame.com@@baidu@@rxtl_s1@@ls /tmp" + "##" + "1007@@172.72.0.3@@www.baiduwebgame.com@@baidu@@rxtl_s2@@ls /tmp" + "##" 
		# 对请求数据串使用m_encode方法加密
		put_string = m_encode(put_string, SECRET_KEY)
		try:
			# paramters host, port
			self.conn =rpyc.connect(self.server, self.port)
			# 是服务端的那个以"exposed_"开头的方法
			self.rLogin =self.conn.root.login("%s" % self.user, "%s" % self.passwd)	
		except Exception, e:
			self.rLogin = False
			return 'Connect to rpyc server error:' + str(e)
			sys.exit()
		if self.rLogin:
			# 调用rpyc Server的Runcommands方法实现功能模块的任务下发，返回结果使用m_decode进行解密
			try:
				cResult =m_decode(self.conn.root.Runcommands(put_string), SECRET_KEY)
				return cResult
			except Exception,e:
				return u"SECRET KEY Error or %s" % e
			self.conn.close()
		else:
			return u"authentication failed"


MangeGameServer()
