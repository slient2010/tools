#!/usr/bin/python
# -*- coding: utf-8 -*-

# 加密密钥串
SECRET_KEY="mmmmasdfklasjdfkdsjkfjjiozji"
# 使用工具
AUTO_PLATFORM = "swall"
# 监听端口
PORT=9911
# 认证用户
USER = "admin"
# 认证用户密码
PASSWD = "mmmmabcdefghijklmnopqrstuvwxyz"
