#!/usr/bin/python
import sys
from tasks import add
import time
result = add.delay(4,4)
sleeptime = int(sys.argv[1])

while not result.ready():
  print "not ready yet"
  time.sleep(sleeptime)

print result.get()
