#!/usr/bin/python
# -*- coding: utf-8 -*-
import time
from celery import Celery
from libs.public_libs.swall.swall.parser import Swall

app = Celery('tasks', backend='redis://:work2015!@172.17.0.2/1', broker='redis://:work2015!@172.17.0.2/0')
#app = Celery('tasks', broker='redis://:work2015!@172.17.0.2/0')
#app.conf.CELERY_RESULT_BACKEND = 'db+sqlite:///results.sqlite'
app.conf.CELERY_RESULT_BACKEND = 'redis://:work2015!@172.17.0.2/1'
app.conf.update(
CELERY_TASK_SERIALIZER = 'json',
CELERY_RESULT_SERIALIZER = 'json',
#CELERY_ACCEPT_CONTENT=['json'],
CELERY_TIMEZONE = 'Europe/Oslo',
CELERY_ENABLE_UTC = True,
)

#@app.task(bind=True,max_retries=3,default_retry_delay=1 * 6)
#@app.task(bind=True, default_retry_delay=300, max_retries=5)
#@app.task
#def add(x, y):
#    time.sleep(30) 
#    #swall = Swall()
#    #testabc = type(swall)
#    #return testabc
#    try:
#        m = x + y + 23
#    except add.FailWhale as exc:
#        raise add.retry(countdown=60 * 5, exc = exc)
#    return 'testing' + str(m)
#

@app.task
def runcmd(sys_param_row):
    time.sleep(1) 
    Runresult = "no result"
    try:
        if not sys_param_row:
            return Runresult
        swall = Swall()
        domain = str(sys_param_row['domain'])
        ip = str(sys_param_row['ip'])
        gamename = str(sys_param_row['gamename'])
        platname = str(sys_param_row['platname'])
        action = str(sys_param_row['action'])
        p_a_g = '*' + u'%s' % platname + '*' + ip + '*'+ gamename
        PlatAndGame = []
        PlatAndGame.append(p_a_g)
        if '0' in action.split('&')[0]:
            action = "stop_game"
        elif '1' in action.split('&')[0]:
            action = "start_game"
        elif '2' in action.split('&')[0]:
            action = "restart_game"
        # 更新，�参数较多，后端解析
        elif '3' in action.split('&')[0]:
#            action = "update_game"
            action = action.replace('3&', 'update_game&')
        elif '4' in action.split('&')[0]:
            action = "merge_games"
        if '&' in str(sys_param_row['action']):
            #params = {'version':sys_param_row['action'].split('&')[1],'game_status':sys_param_row['action'].split('&')[2]}
            #Runresult = swall.main(list(set(PlatAndGame)), str(sys_param_row['action']))
            Runresult = swall.main(list(set(PlatAndGame)), action)
        else:
            Runresult = swall.main(list(set(PlatAndGame)), action)

        if not Runresult:
            #Runresult = u"No hosts found"
            Runresult = 2
        return u'%s' % Runresult
    except Exception,e:
        Runresult = str(e)      

