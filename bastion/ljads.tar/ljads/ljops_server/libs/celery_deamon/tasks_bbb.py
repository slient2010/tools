#!/usr/bin/python
# -*- coding: utf-8 -*-
import time
import json
import urllib2
#from __future__ import absolute_imort 
from datetime import timedelta
from celery import Celery
from libs.public_libs.swall.swall.parser import Swall

app = Celery('celery_deamon', 
                 backend='redis://:work2015!@172.17.0.2/5', 
                 broker='redis://:work2015!@172.17.0.2/6', 
                 include=["libs.celery_deamon.tasks_new"]
            )

app.conf.update(
    CELERY_TASK_SERIALIZER = 'json',
    CELERY_RESULT_SERIALIZER = 'json',
    #CELERY_ACCEPT_CONTENT=['json'],
    CELERY_TIMEZONE = 'Europe/Oslo',
    CELERY_ENABLE_UTC = True,

    CELERY_ROUTES = {
        #"celery_deamon.tasks_new.get_online":{"queue":"online"},
        "libs.celery_deamon.tasks_new.get_online":{"queue":"online"},
    },

    CELERYBEAT_SCHEDULE = {
        "get_online":{
            "task":"libs.celery_deamon.tasks_new.get_online",
            "schedule": timedelta(seconds=10),
            "args":(65, 23)
        },
    },
)

@app.task
def get_online(x, y):
     return x + y
      

#def get_online():
#    time.sleep(1) 
#    Runresult = "no result"
#    try:
#        swall = Swall()
#       #domain = str(sys_param_row['domain'])
#       #ip = str(sys_param_row['ip'])
#       #gamename = str(sys_param_row['gamename'])
#       #platname = str(sys_param_row['platname'])
#       #action = str(sys_param_row['action'])
#       #p_a_g = '*' + u'%s' % platname + '*' + ip + '*'+ gamename
#        p_a_g = '*'
#        PlatAndGame = []
#        PlatAndGame.append(p_a_g)
#        action = "users_online"
#        Runresult = swall.main(list(set(PlatAndGame)), action)
#
#        if not Runresult:
#            Runresult = u"No hosts found"
#        return u'%s' % Runresult
#    except Exception,e:
#        Runresult = str(e)      
