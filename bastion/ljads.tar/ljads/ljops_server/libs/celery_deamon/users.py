# -*- coding: utf-8 -*-
 
#from __future__ import absolute_import
from celery import Celery
import time
from datetime import timedelta
from libs.public_libs.swall.swall.parser import Swall

app = Celery("proj",
             broker="redis://:work2015!@localhost/12",
             backend="redis://:work2015!@localhost/13",
            )
 
app.conf.update(
    CELERY_ROUTES={
        "libs.celery_deamon.users.get_users":{"queue":"hipri"},
        },
    CELERYBEAT_SCHEDULE={
        "get_users":{
            "task":"libs.celery_deamon.users.get_users",
            "schedule":timedelta(seconds=60),
            "args":()
            },
        },
    )

@app.task
def get_users():
    time.sleep(1) 
    Runresult = "no result"
    try:
        swall = Swall()
        p_a_g = '*'
        PlatAndGame = []
        PlatAndGame.append(p_a_g)
        action = "users_online"
        Runresult = swall.main(list(set(PlatAndGame)), action)

        #if not Runresult:
        #    Runresult = u"No hosts found"
        #return u'%s' % Runresult
    except Exception,e:
        Runresult = str(e)      

#print get_users()
