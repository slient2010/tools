#!/usr/bin/python
# -*- coding: utf-8 -*-
# 导入 swall模块
import sys, os
sys.path.insert(0, os.path.join(sys.path[0], 'libs/public_libs/swall'))
from libs.public_libs.swall.swall.parser import Swall
from libs.libraries import *
import redis

class Modulehandle():
    def __init__(self, sys_param_row): # 初始化方法
        self.Runresult = ""
        self.sys_param_row = sys_param_row
        # self.hosts = target_host(hosts, "IP")

    def get_latest_version(self, version_type):
        self.version_type = version_type
        if self.version_type == '0':
            self.Runresult = "2015042301@@201503201@@2015040201"
        elif self.version_type == '1':
            self.Runresult = "un_20150424_01_gbk.zip@@un_20150427_01_gbk.zip@@un_20150427_01_gbk.zip"
        else:
            self.Runresult = ""
         
       #try:
       #    self.Runresult = "un_20150424_01_gbk.zip@@un_20150427_01_gbk.zip@@un_20150427_01_gbk.zip"
       #except Exception,e:
       #     return str(e)
        # 返回执行结果
        return self.Runresult

    def managegame(self):
        try:
            from libs.celery_deamon.tasks import runcmd
            result = runcmd.delay(self.sys_param_row)
            if result.status == "PENDING":
                self.Runresult = {'taskid':'%s' % result.id, 'status':'%s' % result.status }
            else:
                get_task_result = str(result.get())
                self.Runresult = {'taskid':'%s' % result.id, 'result':'%s' % get_task_result}
            if len(self.Runresult) == 0:
                return "No hosts found, 请确认主机已经添加到zookeeper环境！"
        except Exception,e:
             return str(e)
        # 返回执行结果

        return self.Runresult

    def gettaskresult(self, task_id):
        self.task_id = task_id
        try:
            #if len(self.sys_param_row) < 1:
            #    return self.Runresult
            r = redis.Redis(host='172.17.0.2', port=6379,password='work2015!',db=1)
            #retval = add.AsyncResult(task_id).get()
            retval =  r.get('celery-task-meta-%s' % self.task_id)
            if retval:
                if 'null' in retval:
                    null = "none"
                self.Runresult =  "%s" % eval(retval)['result']
            else:
                self.Runresult =  "none"
            if len(self.Runresult) == 0:
                return "No hosts found, 请确认主机已经添加到zookeeper环境！"
            return self.Runresult
        except Exception,e:
             return str(e)
        # 返回执行结果

    def canceltask(self, task_id):
        
        #from libs.celery_deamon.tasks import *
        import celery
        from celery import Celery
        
        app = Celery('tasks', backend='redis://:work2015!@172.17.0.2/1', broker='redis://:work2015!@172.17.0.2/0')
        app.conf.CELERY_RESULT_BACKEND = 'redis://:work2015!@172.17.0.2/1'
        app.conf.update(
        CELERY_TASK_SERIALIZER = 'json',
        CELERY_RESULT_SERIALIZER = 'json',
        #CELERY_ACCEPT_CONTENT=['json'],
        CELERY_TIMEZONE = 'Europe/Oslo',
        CELERY_ENABLE_UTC = True,
        )

        self.task_id = task_id
        try:
            #if len(self.sys_param_row) < 1:
            #    return self.Runresult
            #task_cancel = celery.task.control.revoke(self.task_id, terminate=True)
            r = redis.Redis(host='172.17.0.2', port=6379, password='work2015!', db=1)
            #retval = add.AsyncResult(task_id).get()
            retval =  r.get('celery-task-meta-%s' % self.task_id)
            if not retval:
                task_cancel = celery.task.control.revoke(self.task_id, terminate=True)
                return """task cancelled!"""
            else:
                return """sorry the task has finished!"""

        except Exception,e:
             return """error %s Hello world: <a href='/result/%s'>%s</a>""" % (str(e), task_id, task_id)
        # 返回执行结果
