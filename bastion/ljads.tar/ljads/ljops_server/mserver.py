#!/usr/bin/python
# -*- coding: utf-8 -*-
# 
# 说明: 作为节点服务端，接受来自客户端的请求，执行相应操作，然后返回即可
# 
# 


import json
import urllib2
import time
import os, sys, atexit
from signal import SIGTERM 
# import re
# from cPickle import dumps
from rpyc import Service
from rpyc.utils.server import ThreadedServer
import logging
# user functions and configure
from libs.libraries import *
from config import *

# 定义服务器端模块存放路径
sysdir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.sep.join((sysdir, 'modules/' + AUTO_PLATFORM)))

class Daemon():
    #def __init__(self, pidfile, stdin=stdin, stdout=stdout, stderr=stderr):
    def __init__(self, pidfile, stdin, stdout, stderr, logger):
        self.pidfile= pidfile 
        self.stdin = stdin
        self.stdout = stdout
        self.stderr = stderr
        self.logger = logger

    #创建守护子进程
    def _daemonize(self):
        try:
            pid = os.fork()
            # 退出主进程
            if pid > 0:
                sys.exit(0)
        except OSError, e:
            sys.stderr.wirte('fork #1 failed: %d (%s)\n' % (e.errno, e.strerror))
            logger.info('fork #1 failed: %d (%s)\n' % (e.errno, e.strerror))
            sys.exit(1)
        os.chdir("/")
        os.umask(0)
        os.setsid()
        try:
            pid = os.fork()
            if pid > 0:
                sys.exit(0)
        except OSError, e:
            sys.stderr.wirte('fork #2 failed: %d (%s)\n' % (e.errno, e.strerror))
            logger.info('fork #2 failed: %d (%s)\n' % (e.errno, e.strerror))
            sys.exit(1)
        #进程已经是守护进程，重定向标准文件描述符
        for f in sys.stdout, sys.stderr: f.flush()
        si = file(self.stdin, 'r')
        so = file(self.stdout,'a+')
        se = file(self.stderr,'a+',0)
        os.dup2(si.fileno(), sys.stdin.fileno())
        os.dup2(so.fileno(), sys.stdout.fileno())
        os.dup2(se.fileno(), sys.stderr.fileno())
           
        #创建processid文件
        atexit.register(self.delpid)
        pid = str(os.getpid())
        file(self.pidfile,'aw+').write('%s\n' % pid)

    def delpid(self):
        os.remove(self.pidfile)

    def _run(self):
        message = 'Starting m_server daemon...' 
        logger.info("%s" % message)
        # 开启监听服务
        while True:
            try:
                s = ThreadedServer(ManagerService, port=PORT, auto_register=False)  
                # 启动rpyc服务监听、接受、响应请求
                s.start()
            except Exception, e:
                message = 'Starting service error!'
                logger.error(message)
                sys.exit()
                
   
    def start(self):
        #检查pid文件是否存在以探测是否存在进程
        try:
            pf = file(self.pidfile,'r')
            pid = int(pf.read().strip())
            pf.close()
        except IOError:
            pid = None
        
        if pid:
            message = 'pidfile %s already exist. Daemon already running?' % self.pidfile
            logger.warning("%s" % message)
            sys.stderr.write(message+'\n')
            sys.exit(1)
        else:
            message = 'Starting m_server daemon...' 
            sys.stdout.write(message+'\n')

        #启动监控
        self._daemonize()
        self._run()

    def status(self):
        try:
            pf = file(self.pidfile,'r')
            pid = int(pf.read().strip())
            pf.close()
        except IOError:
            pid = None
        
        if pid:
            message = 'mserver is [\033[0;32;1mrunning\033[0m]...'
        else:
            message = "mserver is [\033[1;31;1mstopped\033[0m]."
        sys.stderr.write(message+'\n')

    def stop(self):
        #读取pid
        try:
            pf = file(self.pidfile, 'r')
            pid = int(pf.read().strip())
            pf.close()
        except IOError:
            pid = None
    
        if not pid:
            message = 'pidfile %s does not exist. Daemon not running?' % (self.pidfile)
            logger.warning("%s" % message)
            sys.stderr.write(message+'\n')
            return #重启不报错
        #杀进程
        try:
            while 1:
                os.kill(pid, SIGTERM)
                time.sleep(0.1)
                message = "Stop listening services...."
                # print "[%s] Stop listening all services...." % end_time
                sys.stdout.write(message + '\n')
                logger.info("%s" % message)
        except OSError, err:
            err = str(err)
            if err.find('No such process') > 0:
                if os.path.exists(self.pidfile):
                    os.remove(self.pidfile)
            else:
                print str(err)
                logger.info("%s" % str(err))
                sys.exit(1)
    
    def restart(self):
        self.stop()
        self.start()

# 服务器管理类
class ManagerService(Service):
    def exposed_login(self, user, passwd):
	if user == USER and passwd == PASSWD:
            self.Checkout_pass = True
        else:
            self.Checkout_pass = False
        return self.Checkout_pass
    
    def exposed_Runcommands(self, get_string):
        try:	        
            if self.Checkout_pass != True:
                return m_encode(r"用户验证失败!", SECRET_KEY)
        except:
	    return m_encode(r"非法登录!", SECRET_KEY)
        self.get_string_array = m_decode(get_string, SECRET_KEY).split('##') 
        Runmessages = []
        while '' in self.get_string_array:
           self.get_string_array.remove('')
        for i in range(len(self.get_string_array)):
            self.get_detail = self.get_string_array[i].split('@@')
            if len(self.get_detail) == 6:
                self.ModuleId = self.get_detail[0]
                self.need_to_add = {'mid':self.get_detail[0], 'ip':self.get_detail[1], \
                                'domain':self.get_detail[2], 'platname':self.get_detail[3], \
                                'gamename':self.get_detail[4], 'action':self.get_detail[5]}
                mid = "Mid_" + self.ModuleId
                importsting = "from modules." + AUTO_PLATFORM + "." + mid + " import Modulehandle"
                try:
                    exec importsting
                except Exception,e :
                    print e
                    return m_encode(u"module\"" + mid + u"\" does not exist, please add it", SECRET_KEY)
                print self.need_to_add
                Runobj = Modulehandle(dict(self.need_to_add))
                #if self.get_detail[5] == "start" or self.get_detail[5] == "1" or self.get_detail[5] == "stop" or self.get_detail[5] == "restart":
                #print self.get_detail[5]


                # 0-stop, 1-start, 2-restart, 3-updates, 4-merge, 5-cancel, 6-check_status, 7-get_backend_version

                if self.get_detail[5] == '0' or self.get_detail[5] == '1' or self.get_detail[5] == '2' or self.get_detail[5] == '4' or '3' in self.get_detail[5] or 'users_online' in self.get_detail[5]:
                    # execute job then return taskid
                    run_job = Runobj.managegame()
                    Runmessages.append(run_job)
                elif '7' in self.get_detail[5]:
                    version_type = self.get_detail[5].split('&')[1]
                    run_job = Runobj.get_latest_version(version_type)
                    Runmessages.append(run_job)
                else:
                    Runmessages = Runobj.runcmd()
           
            elif len(self.get_detail) == 3 and self.get_detail[2] == "cancel":
                mid = "Mid_" + self.get_detail[0]
                importsting = "from modules." + AUTO_PLATFORM + "." + mid + " import Modulehandle"
                exec importsting
                self.need_to_add = {'mid': self.get_detail[0], 'taskid':self.get_detail[1]}
                Runobj = Modulehandle(dict(self.need_to_add))
                run_job = Runobj.canceltask(self.need_to_add['taskid'])
                Runmessages.append(run_job)
            else:
                mid = "Mid_" + self.get_detail[0]
                importsting = "from modules." + AUTO_PLATFORM + "." + mid + " import Modulehandle"
                exec importsting
                self.need_to_add = {'mid': self.get_detail[0], 'taskid':self.get_detail[1]}
                Runobj = Modulehandle(list(self.need_to_add))
                Runmessages = Runobj.gettaskresult(self.need_to_add['taskid'])
            if type(Runmessages) == dict:
                returnString = str(Runmessages)
            else:
                returnString = str(Runmessages).strip()				
        return m_encode(returnString, SECRET_KEY)

    def exposed_Postresult(self, get_string):
        get_string = m_decode(get_string, SECRET_KEY)  
        try:
            if '@' in get_string: 
                 return_string = get_string.split('@')[0]
                 nowtime = get_string.split('@')[1]
                 project = return_string.split('-')[0]
                 servername = return_string.split('-')[1]
                 platname = return_string.split('-')[2]
                 return_users_online = return_string.split('-')[3]
                 values = {"%s" % project :[{'servername':'%s' % servername, 'ptname':'%s' % platname, 'onlines':return_users_online, 'nowtime':nowtime}]}
            else:
                project = get_string.split('-')[0]
                servername = get_string.split('-')[1]
                platname = get_string.split('-')[2]
                return_status = get_string.split('-')[3]
                if len(get_string.split('-')) > 4:
                    package_version = get_string.split('-')[4]
                    values = {"%s" % project :[{'servername':'%s' % servername, 'ptname':'%s' % platname, 'status':return_status, 'packagename':'%s' %package_version}]}
                else:
                    values = {"%s" % project :[{'servername':'%s' % servername, 'ptname':'%s' % platname, 'status':return_status}]}
            url='http://168.168.7.80:8000/apicheck/status'
            jdata = json.dumps(values)
            req = urllib2.Request(url, jdata)
            response = urllib2.urlopen(req)   
            if response.read():
                result = "action success"
            else:
                result = "update state error"
            return m_encode(result, SECRET_KEY)        
        except:
            result = "api error"
        finally:
            return m_encode(result, SECRET_KEY)        


if __name__ == "__main__":
    # 启用日志系统记录
    log_path = sys.path[0] + '/logs/sys.log'
    logging.basicConfig(level = logging.DEBUG,
                format = '[%(asctime)s] [%(levelname)-4s] %(message)s',
                filename = '%s' % log_path,
                filemode = 'a')
    logger = logging.getLogger("logging")


    # 检查配置文件
    # path_pre = os.getcwd()
    config= sys.path[0] + '/' + 'config.py'
    if not os.path.exists(config):
        logger.error('configure file %s does not exists, no such file.' % (config))
        print "Open %s failed, no such file." % (config)
        sys.exit()

    if len(sys.argv) == 2:
        daemon = Daemon('/tmp/mserver_process.pid', '/dev/null', '%s' % log_path, '%s' % log_path, logger)
        if sys.argv[1] == 'start':
            daemon.start()
        elif sys.argv[1] == 'stop':
            daemon.stop()
        elif  sys.argv[1] == 'restart':
            daemon.restart()
        elif sys.argv[1] == 'status':
            daemon.status()            
        else:
            print 'Usage: %s (start|stop|status|restart)' % sys.argv[0]
            sys.exit(0)
        sys.exit(0)
    else:
        print 'Usage: %s (start|stop|status|restart)' % sys.argv[0]
        sys.exit(2)
