import urllib
import urllib2
import json
import time

def http_post():
    timeStamp = int(time.time())
    timeArray = time.localtime(timeStamp)
    otherStyleTime = time.strftime("%Y-%m-%d %H:%M:%S", timeArray)
    url='http://168.168.7.80:8000/apicheck/status'
    values ={"rxtl":[{'servername':'s1','ptname':'37wan','onlines':100, 'nowtime':'%s' % otherStyleTime }]}
    jdata = json.dumps(values)
    print jdata
    req = urllib2.Request(url, jdata)
    response = urllib2.urlopen(req)
    return response.read()
resp = http_post()
print resp

